# QR Work Sessions — Тестер

Простая веб-страница для проверки работы API сервиса **QR Work Sessions**, размещённого на Render.

Сайт позволяет:
- Проверить соединение с API (/ping);
- Создать администратора;
- Войти в систему (admin/user);
- Тестировать ввод QR-кодов вручную или через камеру;
- Проверять синхронизацию офлайн-данных.

## 🌐 Онлайн-версия
После включения GitHub Pages открой сайт по адресу:
https://<твоя_ссылка>.github.io/qr-work-sessions-tester/

## ⚙️ Настройки по умолчанию
API-адрес уже прописан:
https://qr-work-sessions-api.onrender.com

## 🔑 Данные для входа
Email: admin@example.com
Пароль: password

Если админ ещё не создан — используй токен (из Render → Environment → SEED_TOKEN):
+PJ/XrubTn6P27KRKSAiodTyglzoQO7InuDWTglY/4g=

## 📄 Автор
Создан совместно с ChatGPT и Stas270281
